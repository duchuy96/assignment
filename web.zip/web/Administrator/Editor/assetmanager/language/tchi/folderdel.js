function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "\u78ba\u5b9a\u522a\u9664\u6b64\u8cc7\u6599\u593e ?";

    document.getElementById("btnClose").value = "\u95dc\u9589 ";
    document.getElementById("btnDelete").value = "\u522a\u9664 ";
	}
function writeTitle()
	{
	document.write("<title>Delete Folder</title>")
	}
