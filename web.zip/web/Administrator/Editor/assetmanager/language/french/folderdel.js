function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "Etes vous sur de vouloir effacer ce r\u00E9pertoire ?";

    document.getElementById("btnClose").value = "fermer";
    document.getElementById("btnDelete").value = "effacer";
    }
function writeTitle()
    {
    document.write("<title>Suppression de r\u00E9pertoires</title>")
    }
