function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "B?n c� mu?n x�a kh�ng you want to delete this folder?";

    document.getElementById("btnClose").value = "close";
    document.getElementById("btnDelete").value = "delete";
	}
function writeTitle()
	{
	document.write("<title>Delete Folder</title>")
	}
