function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "Vil du slette denne mappen?";

    document.getElementById("btnClose").value = "Lukk";
    document.getElementById("btnDelete").value = "Slett";
    }
function writeTitle()
    {
    document.write("<title>Slette mappe</title>")
    }
