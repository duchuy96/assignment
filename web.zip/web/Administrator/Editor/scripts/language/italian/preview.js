function loadTxt()
    {
    document.getElementById("btnClose").value = "chiudi";
    }
function writeTitle()
    {
    document.write("<title>Anteprima</title>")
    }