function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "Parola da incollare (CTRL-V) ";
    document.getElementById("btnCancel").value = "cancella";
    document.getElementById("btnOk").value = " ok ";   
	}
function writeTitle()
	{
	document.write("<title>Incolla da Word</title>")
	}
