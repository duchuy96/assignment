function loadTxt()
    {
    document.getElementById("btnClose").value = "Lukk";
    }
function writeTitle()
    {
    document.write("<title>Eksempel</title>")
    }