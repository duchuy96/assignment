function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "\u4ece MS Word\u8d34\u4e0a\u5185\u5bb9  (CTRL-V) ";
    document.getElementById("btnCancel").value = "\u53d6\u6d88 ";
    document.getElementById("btnOk").value = " \u786e\u8ba4  ";   
	}
function writeTitle()
	{
	document.write("<title>\u4ece MS Word\u8d34\u4e0a\u5185\u5bb9 </title>")
	}
