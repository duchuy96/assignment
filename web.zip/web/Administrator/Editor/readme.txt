InsiteCreation WYSIWYG Editor 3.0
Copyright � 2007, Insite Mitra Inovindo (www.insitecreation.com). All rights reserved.
____________________________________________________________________


*** Installation ***
1. Unzip the package & copy all files into your web folder.
(To run several examples, it is recomended that you copy all files into http://yourserver/Editor/  or http://localhost/Editor/)
2. To browse the examples, open default.htm 
(http://yourserver/Editor/default.htm  or http://localhost/Editor/default.htm)


*** Upgrade & Support ***
We provide 1 year FREE upgrade and support (support@insitecreation.com) for every purchase of license. 


Thank you for using our product.

____________________________________________________________________
http://www.insitecreation.com
